const navMenu = document.getElementById("nav-menu"),
  navToggle = document.getElementById("nav-toggle-btn"),
  navClose = document.getElementById("nav-close-btn");

/* abre o menu */
if (navToggle) {
  navToggle.addEventListener("click", () => {
    navMenu.classList.add("show-menu");
  });
}

/* esconde o menu */
if (navClose) {
  navClose.addEventListener("click", () => {
    navMenu.classList.remove("show-menu");
  });
}
